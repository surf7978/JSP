package co.mini_project.project.vo;

public class FoodVO {
	private int mNumber;
	private String mKind;
	private String mName;
	private String mPrice;
	private String mContent;
	private String mImage;

	public FoodVO() {

	}

	public int getmNumber() {
		return mNumber;
	}

	public void setmNumber(int mNumber) {
		this.mNumber = mNumber;
	}

	public String getmKind() {
		return mKind;
	}

	public void setmKind(String mKind) {
		this.mKind = mKind;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmPrice() {
		return mPrice;
	}

	public void setmPrice(String mPrice) {
		this.mPrice = mPrice;
	}

	public String getmContent() {
		return mContent;
	}

	public void setmContent(String mContent) {
		this.mContent = mContent;
	}

	public String getmImage() {
		return mImage;
	}

	public void setmImage(String mImage) {
		this.mImage = mImage;
	}

}
