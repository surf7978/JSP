package co.mini_project.project.vo;

public class FranchiseVO {
	private int fNumber;
	private String fName;
	private String fEmail;
	private int fAge;
	private String fTel;
	private String fAddress;
	private String fContent;

	public FranchiseVO() {

	}

	public int getfNumber() {
		return fNumber;
	}

	public void setfNumber(int fNumber) {
		this.fNumber = fNumber;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getfEmail() {
		return fEmail;
	}

	public void setfEmail(String fEmail) {
		this.fEmail = fEmail;
	}

	public int getfAge() {
		return fAge;
	}

	public void setfAge(int fAge) {
		this.fAge = fAge;
	}

	public String getfTel() {
		return fTel;
	}

	public void setfTel(String fTel) {
		this.fTel = fTel;
	}

	public String getfAddress() {
		return fAddress;
	}

	public void setfAddress(String fAddress) {
		this.fAddress = fAddress;
	}

	public String getfContent() {
		return fContent;
	}

	public void setfContent(String fContent) {
		this.fContent = fContent;
	}

}
