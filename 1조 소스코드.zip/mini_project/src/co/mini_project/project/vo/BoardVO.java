package co.mini_project.project.vo;

public class BoardVO {

	private int bNumber;
	private String bTitle;
	private String bKind;
	private String bContent;
	private String mId;

	public BoardVO() {

	}

	public int getbNumber() {
		return bNumber;
	}

	public void setbNumber(int bNumber) {
		this.bNumber = bNumber;
	}

	public String getbTitle() {
		return bTitle;
	}

	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}

	public String getbKind() {
		return bKind;
	}

	public void setbKind(String bKind) {
		this.bKind = bKind;
	}

	public String getbContent() {
		return bContent;
	}

	public void setbContent(String bContent) {
		this.bContent = bContent;
	}

	public String getmId() {
		return mId;
	}

	public void setmId(String mId) {
		this.mId = mId;
	}

}
