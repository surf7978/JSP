package co.mask.cart.vo;

public class CartVo {
	private int cartNumber;
	private String cartUser;
	private int cartProduct;
	private int cartSelect;
	private int productNum;
	private String productName;
	private int productQunt;
	private int productPrice;
	private String ProductSeller;

	public int getCartNumber() {
		return cartNumber;
	}

	public void setCartNumber(int cartNumber) {
		this.cartNumber = cartNumber;
	}

	public String getCartUser() {
		return cartUser;
	}

	public void setCartUser(String cartUser) {
		this.cartUser = cartUser;
	}

	public int getCartProduct() {
		return cartProduct;
	}

	public void setCartProduct(int cartProduct) {
		this.cartProduct = cartProduct;
	}

	public int getCartSelect() {
		return cartSelect;
	}

	public void setCartSelect(int cartSelect) {
		this.cartSelect = cartSelect;
	}

	public int getProductNum() {
		return productNum;
	}

	public void setProductNum(int productNum) {
		this.productNum = productNum;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductQunt() {
		return productQunt;
	}

	public void setProductQunt(int productQunt) {
		this.productQunt = productQunt;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductSeller() {
		return ProductSeller;
	}

	public void setProductSeller(String productSeller) {
		ProductSeller = productSeller;
	}

}
