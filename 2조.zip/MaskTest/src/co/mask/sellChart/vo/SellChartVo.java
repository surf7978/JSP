package co.mask.sellChart.vo;

public class SellChartVo {
	private String chartProduct;
	private int chartProductNum;
	private int chartProductQunt;
	private String chartSeller;
	
	

	public String getChartSeller() {
		return chartSeller;
	}

	public void setChartSeller(String chartSeller) {
		this.chartSeller = chartSeller;
	}

	public String getChartProduct() {
		return chartProduct;
	}

	public void setChartProduct(String chartProduct) {
		this.chartProduct = chartProduct;
	}

	public int getChartProductNum() {
		return chartProductNum;
	}

	public void setChartProductNum(int chartProductNum) {
		this.chartProductNum = chartProductNum;
	}

	public int getChartProductQunt() {
		return chartProductQunt;
	}

	public void setChartProductQunt(int chartProductQunt) {
		this.chartProductQunt = chartProductQunt;
	}

}
