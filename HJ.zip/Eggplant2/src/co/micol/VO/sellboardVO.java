package co.micol.VO;

public class sellboardVO {

	private String tNumber;
	private String tTitle;
	private String tContent;
	private String tDate;
	private int tPrice;
	private String tImage;
	private String tAddress;
	private String tId;
	private int tDiscount;
	private int tViews;
	private int tLikes;
	private String pName;
	private String pColor;
	private int pVolume;
	
	
	public sellboardVO() {
		// TODO Auto-generated constructor stub
	}


	public String gettNumber() {
		return tNumber;
	}


	public void settNumber(String tNumber) {
		this.tNumber = tNumber;
	}


	public String gettTitle() {
		return tTitle;
	}


	public void settTitle(String tTitle) {
		this.tTitle = tTitle;
	}


	public String gettContent() {
		return tContent;
	}


	public void settContent(String tContent) {
		this.tContent = tContent;
	}


	public String gettDate() {
		return tDate;
	}


	public void settDate(String tDate) {
		this.tDate = tDate;
	}


	public int gettPrice() {
		return tPrice;
	}


	public void settPrice(int tPrice) {
		this.tPrice = tPrice;
	}


	public String gettImage() {
		return tImage;
	}


	public void settImage(String tImage) {
		this.tImage = tImage;
	}


	public String gettAddress() {
		return tAddress;
	}


	public void settAddress(String tAddress) {
		this.tAddress = tAddress;
	}


	public String gettId() {
		return tId;
	}


	public void settId(String tId) {
		this.tId = tId;
	}


	public int gettDiscount() {
		return tDiscount;
	}


	public void settDiscount(int tDiscount) {
		this.tDiscount = tDiscount;
	}


	public int gettViews() {
		return tViews;
	}


	public void settViews(int tViews) {
		this.tViews = tViews;
	}


	public int gettLikes() {
		return tLikes;
	}


	public void settLikes(int tLikes) {
		this.tLikes = tLikes;
	}


	public String getpName() {
		return pName;
	}


	public void setpName(String pName) {
		this.pName = pName;
	}


	public String getpColor() {
		return pColor;
	}


	public void setpColor(String pColor) {
		this.pColor = pColor;
	}


	public int getpVolume() {
		return pVolume;
	}


	public void setpVolume(int pVolume) {
		this.pVolume = pVolume;
	}
	
	
}
