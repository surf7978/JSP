select * from member1;



SELECT * FROM member1 WHERE memberid = 'admin' AND mpassword = 'admin';


INSERT INTO book
				(bookcode, bookname)
			VALUES(2222,'2��å');

commit;

UPDATE book
				 SET bcount = bcount-5
				 WHERE bookcode = 1111;

select * from book;

INSERT INTO bookrental
				(bookcode, memberid)
				 VALUES( 1111, 'admin');

UPDATE bookrental
				SET RETURNDATE = (to_char(sysdate,'yyyy/mm/dd hh24:mi:ss'))
				 WHERE rentalDate = '2021/02/02 09:58:14';

select to_char(sysdate,'yyyy/mm/dd hh24:mi:ss')   from dual ;

select * from BOOKRENTAL;

COMMIT;

SELECT * FROM bookrental WHERE bookcode = '2222';

SELECT * FROM bookrental WHERE memberid = 'aaa' ORDER BY 1;

---------

create table book99(BookCode varchar2(4) not null primary key,
BookName varchar2(100) not null , Quantity number default 5 not null , bCount number default 5 not null);

insert into book99(bookcode, bookname) values('1111','1��å');
insert into book99(bookcode, bookname) values('222','2��å');
insert into book99(bookcode, bookname) values('33','3��å');

create table member99(MemberId varchar2(10) not null primary key,
MemberName varchar2(20) not null , MemberPassword varchar2(20) not null
,MemberTel varchar2(20) not null, MemberAddress varchar2(100), MemberAuth varchar2(10) default 'USER' );

insert into member99(MemberId, MemberName, MemberPassword, MemberTel, MemberAddress, MemberAuth) 
values('admin','������', 'admin', '010-1111-2222', '�뱸��', 'ADMIN');
insert into member99(MemberId, MemberName, MemberPassword, MemberTel, MemberAddress) 
values('park','��', '1234', '010-1234-5678', '�����');

create table bookrental99(RentalDate varchar2(20) default to_char(sysdate,'yyyy/mm/dd hh24:mi:ss') not null,
BookCode varchar2(4) not null , MemberId varchar2(10) not null
,ReturnDate varchar2(20));

drop table book99;
drop table member99;
drop table bookrental99;

commit;

UPDATE book99
				 SET likeIt = likeIt + 1
				 WHERE bookcode = 1111;
         
select * from book99;
